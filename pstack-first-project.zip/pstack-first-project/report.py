import argparse
import csv


def main():
    parser = argparse.ArgumentParser(description="CSVの支出を集計します")
    parser.add_argument("csv_file")
    args = parser.parse_args()
    with open(args.csv_file, encoding="utf-8", newline="") as source:
        rows = list(csv.DictReader(source))
    total = sum(int(row["amount"]) for row in rows)
    print(f"件数: {len(rows)}")
    print(f"合計: {total}円")


if __name__ == "__main__":
    main()
