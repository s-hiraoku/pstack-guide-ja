import os
from pathlib import Path
import subprocess
import sys
import unittest


ROOT = Path(__file__).resolve().parent


class ReportTests(unittest.TestCase):
    def run_report(self, filename):
        return subprocess.run(
            [sys.executable, str(ROOT / "report.py"), str(ROOT / filename)],
            capture_output=True,
            text=True,
            encoding="utf-8",
            env={**os.environ, "PYTHONIOENCODING": "utf-8"},
            check=True,
        )

    def test_three_expenses(self):
        result = self.run_report("expenses.csv")
        self.assertEqual(result.stdout, "件数: 3\n合計: 3000円\n")
        self.assertEqual(result.stderr, "")

    def test_header_only(self):
        result = self.run_report("empty.csv")
        self.assertEqual(result.stdout, "件数: 0\n合計: 0円\n")
        self.assertEqual(result.stderr, "")


if __name__ == "__main__":
    unittest.main()
