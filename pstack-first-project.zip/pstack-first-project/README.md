# pstack 入門用・支出集計CLI

Lauren Tan版pstackの記事に付属する練習用プロジェクトです。pstack公式のサンプルではありません。

Python 3.10以上とGitを用意し、このフォルダをCursorで開いてください。追加のPythonパッケージは不要です。Windowsで `python3` が見つからない場合は `py -3` に置き換えてください。

```sh
python3 report.py expenses.csv
python3 -m unittest -v
```

通常出力は次のとおりです。

```text
件数: 3
合計: 3000円
```

`empty.csv` は見出しだけのCSVです。件数と合計はともに0です。入力はUTF-8のCSVで、`description,amount` の見出しを持ち、amountは整数円です。壊れた入力への親切なエラー処理は、今回の教材の対象外です。

## 練習開始

新しく展開したこのフォルダで、一度だけ実行してください。

```sh
git init -b main
git add report.py test_report.py expenses.csv empty.csv README.md .gitignore
git commit -m "chore: add pstack tutorial starter"
git switch -c practice/json-output
```

Gitに名前・メールアドレスを求められたら、自分の情報をこのリポジトリに設定し、commitから再開します。リモートリポジトリの登録は不要です。

Cursorでpstackを導入したうえで、次のプロンプトを送ります。

```text
/poteto-mode report.py に --json オプションを追加してください。
--json なしの出力は既存と完全に同じにしてください。
--json ありでは、標準出力を count と total_yen だけのJSONオブジェクトにします。
expenses.csv は count=3、total_yen=3000、empty.csv は両方0です。
数値は文字列でなく整数にしてください。
元の出力を変更前に保存し、既存テストと実際のCLI実行で前後を比較してください。
JSONはパーサーで読み込み、値まで検証してください。
これはローカル演習です。現在の練習ブランチで作業し、commitは可能です。
push、PR作成、merge、公開は行わず、検証結果を示して終了してください。
追加パッケージは使わず、解説は日本語でお願いします。
```

元の教材には `--json` を実装していません。追加前の `--json` 実行がエラーになるのは正常です。

## 終了の目安

- 既存の2テストに加え、JSON出力を確認するテストが通る。
- 通常出力が変わっていない。
- JSONモードを実行し、count/total_yenの数値を確認できる。
- 実行コマンド・実際の結果・変更内容が報告されている。

この教材は個人情報や外部通信を必要としません。証拠を保存する場合は `evidence/` に置きます。このフォルダはGit管理から除外しています。
